

export class DataSet {

    data: any[] = [
        {
            'description': "Test Activation Otf", 'simCommissionType': 'Instant', 'activationEndDate': '2010-10-10',
            'paymentType': 'Easy Load', 'channelPartner': 'DSR', 'createdAt': '2021-12-29'
        },
        {
            'description': "Test Activation Otf", 'simCommissionType': 'Instant', 'activationEndDate': '2010-10-10',
            'paymentType': 'Easy Load', 'channelPartner': 'DSR', 'createdAt': '2021-12-29'
        },
        {
            'description': "Test Activation Otf", 'simCommissionType': 'Instant', 'activationEndDate': '2010-10-10',
            'paymentType': 'Easy Load', 'channelPartner': 'DSR', 'createdAt': '2021-12-29'
        },
        {
            'description': "Test Activation Otf", 'simCommissionType': 'Instant', 'activationEndDate': '2010-10-10',
            'paymentType': 'Easy Load', 'channelPartner': 'DSR', 'createdAt': '2021-12-29'
        },
        {
            'description': "Test Activation Otf", 'simCommissionType': 'Instant', 'activationEndDate': '2010-10-10',
            'paymentType': 'Easy Load', 'channelPartner': 'DSR', 'createdAt': '2021-12-29'
        },
        {
            'description': "Test Activation Otf", 'simCommissionType': 'Instant', 'activationEndDate': '2010-10-10',
            'paymentType': 'Easy Load', 'channelPartner': 'DSR', 'createdAt': '2021-12-29'
        },
        {
            'description': "Test Activation Otf", 'simCommissionType': 'Instant', 'activationEndDate': '2010-10-10',
            'paymentType': 'Easy Load', 'channelPartner': 'DSR', 'createdAt': '2021-12-29'
        },
        {
            'description': "Test Activation Otf", 'simCommissionType': 'Instant', 'activationEndDate': '2010-10-10',
            'paymentType': 'Easy Load', 'channelPartner': 'DSR', 'createdAt': '2021-12-29'
        },
        {
            'description': "Test Activation Otf", 'simCommissionType': 'Instant', 'activationEndDate': '2010-10-10',
            'paymentType': 'Easy Load', 'channelPartner': 'DSR', 'createdAt': '2021-12-29'
        }
    ]


}